require.config({
    urlArgs: 't=636909236004780852'
});