(function() {
	'use strict';
	/*
	var jobManagerModule = window['angular'].module('supervisor', ['headerbar', 'ui.router', 'pascalprecht.translate', 'Components.Notification','messages','components.authentication', 'app.module', 'aboutUsModule',
                                                        'jobs','logs','queuemanager','statistics','dbq', 'wsnavigation', 'ui.bootstrap', 'strs.grid', 'OpenText.StreamServe.Directives.AppSwitcher',
                                                        'components.ottooltip', 'component.settings', 'OpenText.StreamServe.Localization.Loader', 'components.widgets', 'components.eventhandling', 'keyboard.handling']);
	*/
	var jobManagerModule = window['angular'].module('supervisor', ['strs.grid', 'ui.bootstrap', 'ui.router', 'pascalprecht.translate',
		'OpenText.StreamServe.Localization.Loader'
	]);
	
	window['angular'].isUndefinedOrNull = function(val) {
		return window['angular'].isUndefined(val) || val === null;
	}
	
	jobManagerModule.config( ['$translateProvider', '$httpProvider', function( $translateProvider, $httpProvider) {
		/* localization settings starts here */
		$translateProvider.useSanitizeValueStrategy( 'escapeParameters' );
		$translateProvider.useLoader( 'StrsTranslationLoader', { files:[{prefix:'3rdparty/strsgrid/locale/', suffix : '.json'},{prefix:'locale/', suffix : '.json'}] }  );
		var languageParameterRegex = /[\?|&]language=((?:[a-z]{2}(?:[_|\-][a-zA-Z]{2,3})?))/i;
		var languageParam = undefined;
		// cannot use $window service here, because services are not yet available
		var tokens = languageParameterRegex.exec( window.location.href );
		if ( tokens ) {
			languageParam  =  tokens[1];
		}else{
			//Getting browser locale from cookey... sso filter sets this cookey by reading the client request header 
			var cookies = document.cookie.split(';');
			for (var i = 0; i < cookies.length; i++) {
				var c = cookies[i];
				while (c.charAt(0) == ' ')
					c = c.substring(1);
				if (c.indexOf('OT_CC_BROWSER_LOCALE=') == 0)
					languageParam = c.substring('OT_CC_BROWSER_LOCALE='.length, c.length);
			}
		}
		if(!window['angular'].isUndefined(languageParam)){
			$translateProvider.preferredLanguage(languageParam);
		}else {
			$translateProvider.determinePreferredLanguage();
		}
		// Tells angular-translate to use the English language if translations are not available in current selected language
		$translateProvider.fallbackLanguage( 'en' );		
	}] )
})();
