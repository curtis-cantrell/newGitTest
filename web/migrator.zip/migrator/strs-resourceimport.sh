#!/bin/sh


#set -x	# Debug

True=0;
False=1;

usage()
{
	echo "[$script]: Usage: start $script <arguments>";
}

###
# Main

script=`basename $0`;
location=`dirname $0`;

if [ -z "$STRS_LOCATION" ]; then
	#
	# STRS_LOCATION not set: This is set in the "start" script
	#
	exec $location/start $script "$@";
fi

cd $STRS_LOCATION || exit 1;

if [ -z "$STRS_JAVA_HOME" ]; then
	. $STRS_LOCATION/.setup_environment
fi

type $STRS_JAVA_HOME/bin/java >/dev/null 2>&1 || {
	echo "[$script]: java is not installed or not in the path";
	exit 1;
}

classPath="lib/migrator/migrator.jar"

arguments=;
luceneIndexes=;
log4jSpec=;
logpath=;
jvm_args=;
var=;
while true
do
    if [ $# = 0 ]; then
        break;
    fi

    var=$(echo $1 | awk -F"=" '{print $1}');

    if [ "-DluceneIndexes" = $var ]; then
        luceneIndexes="$1";
    else
    if [ "-Dlog4j.configuration" = "$var" ]; then
        log4jSpec="$1";
    else
    if [ "-Dlog.path" = "$var" ]; then
        logpath="$1";
    else
        if [ -z "$arguments" ]; then
            arguments="$1";
        else
            arguments="$arguments $1";
        fi
    fi
    fi
    fi
    shift
done

if [ -n "$luceneIndexes" ]; then
    jvm_args="$luceneIndexes";
fi
if [ -n "$log4jSpec" ]; then
    jvm_args="$jvm_args $log4jSpec";
fi
if [ -n "$logpath" ]; then
    jvm_args="$jvm_args $logpath";
fi
exec $STRS_JAVA_HOME/bin/java $jvm_args -cp $classPath com.streamserve.migratedb.MigrateToWS $arguments
