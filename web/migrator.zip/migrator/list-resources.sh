#!/bin/sh


#set -x	# Debug

True=0;
False=1;

usage()
{
	echo "[$script]: Usage: start $script <arguments>";
}

###
# Main

script=`basename $0`;
location=`dirname $0`;

if [ -z "$STRS_LOCATION" ]; then
	#
	# STRS_LOCATION not set: This is set in the "start" script
	#
	exec $location/start $script "$@";
fi

cd $STRS_LOCATION || exit 1;

if [ -z "$STRS_JAVA_HOME" ]; then
	. $STRS_LOCATION/.setup_environment
fi

type $STRS_JAVA_HOME/bin/java >/dev/null 2>&1 || {
	echo "[$script]: java is not installed or not in the path";
	exit 1;
}

classPath="lib/migrator/migrator.jar"

exec $STRS_JAVA_HOME/bin/java -cp $classPath com.streamserve.migratedb.ListResources "$@"
