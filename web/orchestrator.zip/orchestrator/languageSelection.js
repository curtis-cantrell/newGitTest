const availableLanguages = ['de', 'es', 'fi', 'fr', 'ja', 'nl', 'pt', 'ru', 'sv', 'zh'];
const locationSearchRegex = /[\?&]language=([a-z]{2}(?:[-_][a-z]{2,3})?)?/i;
const languageConfiguration = { 'en': { 'inline': 'inline.f2d633bc3bd0869d9605.bundle.js', 'polyfills': 'polyfills.41022f7b1d1a86a7b8c6.bundle.js', 'main': 'main.39cefb348bbd95183048.bundle.js', 'styles': 'styles.37858f1e5c68dabce757.bundle.css', 'vendor': 'vendor.ecbc1f88bd8f4a45b18e.bundle.js' }, 'de': { 'inline': 'inline.fdbbc5982d5a46199a1f.de.bundle.js', 'main': 'main.1fe97fa3d2c7df66945f.de.bundle.js', 'polyfills': 'polyfills.41022f7b1d1a86a7b8c6.de.bundle.js', 'styles': 'styles.37858f1e5c68dabce757.de.bundle.css', 'vendor': 'vendor.1be53f333ae2a52078b0.de.bundle.js' }, 'es': { 'inline': 'inline.bdb57391d8b42ebc959f.es.bundle.js', 'main': 'main.9d487de9ac4439fc3db6.es.bundle.js', 'polyfills': 'polyfills.41022f7b1d1a86a7b8c6.es.bundle.js', 'styles': 'styles.37858f1e5c68dabce757.es.bundle.css', 'vendor': 'vendor.f639e4a6e455dca756b5.es.bundle.js' }, 'fi': { 'inline': 'inline.ad8b1463f43be857ee36.fi.bundle.js', 'main': 'main.fd21fbc0b6480aeacece.fi.bundle.js', 'polyfills': 'polyfills.41022f7b1d1a86a7b8c6.fi.bundle.js', 'styles': 'styles.37858f1e5c68dabce757.fi.bundle.css', 'vendor': 'vendor.87e7825f460ee28e2684.fi.bundle.js' }, 'fr': { 'inline': 'inline.890b1aac4541c7aa06c1.fr.bundle.js', 'main': 'main.800ddf67782ff32ad5f4.fr.bundle.js', 'polyfills': 'polyfills.41022f7b1d1a86a7b8c6.fr.bundle.js', 'styles': 'styles.37858f1e5c68dabce757.fr.bundle.css', 'vendor': 'vendor.2cc46e46b60369323ec5.fr.bundle.js' }, 'ja': { 'inline': 'inline.be477fe86a9427c2241d.ja.bundle.js', 'main': 'main.db77c21ac465c583f419.ja.bundle.js', 'polyfills': 'polyfills.41022f7b1d1a86a7b8c6.ja.bundle.js', 'styles': 'styles.37858f1e5c68dabce757.ja.bundle.css', 'vendor': 'vendor.7e65473134db8634a1ac.ja.bundle.js' }, 'nl': { 'inline': 'inline.01de5018b6490b958237.nl.bundle.js', 'main': 'main.4dbde55656452c052b4e.nl.bundle.js', 'polyfills': 'polyfills.41022f7b1d1a86a7b8c6.nl.bundle.js', 'styles': 'styles.37858f1e5c68dabce757.nl.bundle.css', 'vendor': 'vendor.4b8e01f23f89b26dbb3b.nl.bundle.js' }, 'pt': { 'inline': 'inline.3ceb3a5c62399133187a.pt.bundle.js', 'main': 'main.5ff24ef91099fea7273b.pt.bundle.js', 'polyfills': 'polyfills.41022f7b1d1a86a7b8c6.pt.bundle.js', 'styles': 'styles.37858f1e5c68dabce757.pt.bundle.css', 'vendor': 'vendor.a1ce46d5948c7ce16b5a.pt.bundle.js' }, 'ru': { 'inline': 'inline.b5d58ccd2abdd390244e.ru.bundle.js', 'main': 'main.9315b0045605722bc54a.ru.bundle.js', 'polyfills': 'polyfills.41022f7b1d1a86a7b8c6.ru.bundle.js', 'styles': 'styles.37858f1e5c68dabce757.ru.bundle.css', 'vendor': 'vendor.59ff23fb736bd4e4c920.ru.bundle.js' }, 'sv': { 'inline': 'inline.53ff2b5a00faf392349f.sv.bundle.js', 'main': 'main.2c4eb2e606c78aa5e419.sv.bundle.js', 'polyfills': 'polyfills.41022f7b1d1a86a7b8c6.sv.bundle.js', 'styles': 'styles.37858f1e5c68dabce757.sv.bundle.css', 'vendor': 'vendor.77e1b443fd810c688dbd.sv.bundle.js' }, 'zh': { 'inline': 'inline.5e17adbc4a1ca0629298.zh.bundle.js', 'main': 'main.1720b878856cfcebe448.zh.bundle.js', 'polyfills': 'polyfills.41022f7b1d1a86a7b8c6.zh.bundle.js', 'styles': 'styles.37858f1e5c68dabce757.zh.bundle.css', 'vendor': 'vendor.978f01f9b6f6d03b2923.zh.bundle.js' } };
function languageSelector() {
    let selectedLanguage = '';
    let fallbackLanguage = '';
    const urlLanguageMatch = locationSearchRegex.exec(location.search) || locationSearchRegex.exec(location.hash);
    if (urlLanguageMatch && urlLanguageMatch[1]) {
        selectedLanguage = urlLanguageMatch[1].toLowerCase().replace('-', '_');
        fallbackLanguage = selectedLanguage.length > 2 ? selectedLanguage.substr(0, 2) : selectedLanguage;
    }
    let chosenLanguage = 'en';
    if (availableLanguages.indexOf(selectedLanguage) > -1) {
        chosenLanguage = selectedLanguage;
    }
    else if (availableLanguages.indexOf(fallbackLanguage) > -1) {
        chosenLanguage = fallbackLanguage;
    }
    console.log('Language selected: ' + chosenLanguage);
    $('html').attr('lang', chosenLanguage);
    const body$ = $('body');
    // styles and polyfills are independent of the UI language, so always using
    // the base files and not deploying duplicate files
    body$.append('<link href="' + languageConfiguration['en'].styles + '" rel="stylesheet"/>');
    const scripts$ = $('<div/>');
    scripts$.append('<script type="text/javascript" src="' + languageConfiguration[chosenLanguage].inline + '"></script>');
    scripts$.append('<script type="text/javascript" src="' + languageConfiguration['en'].polyfills + '"></script>');
    scripts$.append('<script type="text/javascript" src="' + languageConfiguration[chosenLanguage].vendor + '"></script>');
    scripts$.append('<script type="text/javascript" src="' + languageConfiguration[chosenLanguage].main + '"></script>');
    body$.append(scripts$.children());
}
languageSelector();
