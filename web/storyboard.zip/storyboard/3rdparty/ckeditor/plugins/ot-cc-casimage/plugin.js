/**
 * Allows working with cas: urls im image src attributes.
 */
function replaceCasUrls( editor, event ) {
	// replace cas: src in images with rest url
	var content = event.data.dataValue;
	var sgwurl = editor.config.ccm.sgwURL;
	content = content.replace( /(<img[^>]*?src=")cas:(.*?)("[^>]*?\/?>)/g, '$1' + sgwurl + '/resources/$2/content$3' );
	event.data.dataValue = content;
}

CKEDITOR.plugins.add( 'ot-cc-casimage', {
	requires: 'image2',
	onLoad  : function() {
	},
	init    : function( editor ) {
		console.log( 'init ot-cc-casimage' );

		if ( !(editor.config.ccm && editor.config.ccm.sgwURL) ) {
			throw new Error( 'No ServiceGateway url configured' );
		}

		editor.on( 'setData', function( event ) {
			replaceCasUrls( editor, event );
		} );
	}
} );
