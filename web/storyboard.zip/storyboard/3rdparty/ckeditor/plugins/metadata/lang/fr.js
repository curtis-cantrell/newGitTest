CKEDITOR.plugins.setLang( 'metadata', 'fr',
    {
		insertButtonTitle: 'Insérer',
		toolbarButtonTitle : 'Insérer/modifier les métadonnées',
		dialogHeaderTitle : 'Insérer les métadonnées',
		errorMessage : 'Erreur : impossible de récupérer les métadonnées à partir de la passerelle de services.',
		propertiesTitle : "Propriétés"
    }
);