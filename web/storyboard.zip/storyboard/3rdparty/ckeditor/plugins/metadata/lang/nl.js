CKEDITOR.plugins.setLang( 'metadata', 'nl',
    {
		insertButtonTitle: 'Invoegen',
		toolbarButtonTitle : 'Metagegevens invoegen/bewerken',
		dialogHeaderTitle : 'Metagegevens invoegen',
		errorMessage : 'Fout: metagegevens kunnen niet worden opgehaald van ServiceGateway.',
		propertiesTitle : "Eigenschappen"
    }
);