CKEDITOR.plugins.setLang( 'metadata', 'es',
    {
		insertButtonTitle: 'Insertar',
		toolbarButtonTitle : 'Insertar/Editar metadatos',
		dialogHeaderTitle : 'Insertar metadatos',
		errorMessage : 'Error: No se pueden recuperar los metadatos de la puerta de enlace del servicio.',
		propertiesTitle : "Propiedades"
    }
);