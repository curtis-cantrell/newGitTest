CKEDITOR.plugins.setLang( 'metadata', 'ru',
    {
		insertButtonTitle: 'Вставить',
		toolbarButtonTitle : 'Вставить/изменить метаданные',
		dialogHeaderTitle : 'Вставить метаданные',
		errorMessage : 'Ошибка. Не удалось получить метаданные из ServiceGateway.',
		propertiesTitle : "Свойства"
    }
);