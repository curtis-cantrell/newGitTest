CKEDITOR.plugins.setLang( 'metadata', 'de',
    {
		insertButtonTitle: 'Einfügen',
		toolbarButtonTitle : 'Metadaten einfügen/bearbeiten',
		dialogHeaderTitle : 'Metadaten einfügen',
		errorMessage : 'Fehler: Metadaten konnten nicht von ServiceGateway abgerufen werden.',
		propertiesTitle : "Eigenschaften"
    }
);