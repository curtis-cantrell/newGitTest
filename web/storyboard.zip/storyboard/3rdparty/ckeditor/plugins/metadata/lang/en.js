CKEDITOR.plugins.setLang( 'metadata', 'en',
    {
		insertButtonTitle: 'Insert',
		toolbarButtonTitle : 'Insert/Edit Metadata',
		dialogHeaderTitle : 'Insert Metadata',
		errorMessage : 'Error: Unable to retrieve metadata from ServiceGateway.',
		propertiesTitle : 'Properties'
    }
);