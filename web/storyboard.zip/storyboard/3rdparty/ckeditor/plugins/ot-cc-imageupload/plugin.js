/**
 * Plugin to allow image upload of pasted images directly into CAS.
 */
CKEDITOR.plugins.add( 'ot-cc-imageupload', {
	init: function( editor ) {
		console.log( 'init ot-cc-imageupload' );

		var textResourceSubscription;

		if ( !editor.config.ccm.sgwURL) {
			throw new Error( 'ot-cc-imageupload plugin: Missing configuration value' );
		}

		editor.on( 'fileUploadRequest', function( evt ) {
			var fileLoader = evt.data.fileLoader;
			var requestUrl = editor.config.ccm.sgwURL + fileLoader.uploadUrl + '&name=' + fileLoader.fileName;
			if ( editor.config.ccm.parentLogicId ) {
				requestUrl += '&originalsource=' + editor.config.ccm.parentLogicId;
			}
			var textResourceObservable = editor.config.ccm.textResourceObservable;
			if ( textResourceObservable ) {
				textResourceSubscription = textResourceObservable.first().subscribe( function( resource ) {
					if( resource ) {
						handleWithEmbeddedState( resource.isEmbedded && editor.config.ccm.embedImage, evt, fileLoader, requestUrl );
					}
				}, function( error ) {
					throw new Error( 'Could not get information on loaded text resource. ' + error );
				} );
			}

		}, null, null, 4 ); // Listener with a priority 4 will be executed before priority 5.

		editor.on( 'fileUploadResponse', function( evt ) {
			// Prevent the default response handler.
			evt.stop();

			// Get XHR and response.
			var data = evt.data, xhr = data.fileLoader.xhr, response = xhr.responseText.split( '|' );

			if ( response ) {
				var sgwurl = editor.config.ccm.sgwURL;
				var resource = JSON.parse( response ).data;
				data.url = sgwurl + '/resources/' + resource.id + '/content';
				// block should not be needed anymore if following issue is resolved:
				// https://github.com/ckeditor/ckeditor-dev/issues/1180
				setTimeout( function() {
					editor.fire( 'change' );
				} );
			} else {
				evt.cancel();
			}
		} );

		function handleWithEmbeddedState( embed, evt, fileLoader, requestUrl ) {
			var formData = new FormData(), xhr = fileLoader.xhr;
			if ( embed && editor.config.ccm.parentLogicId ) {
				// create image as embedded resource
				requestUrl += '&scopelogicid=' + editor.config.ccm.parentLogicId;
			}
			xhr.open( 'POST', requestUrl, true );
			xhr.setRequestHeader( 'OTDSTicket', editor.config.ccm.otdsTicket );

			formData.append( 'file', fileLoader.file, fileLoader.fileName );
			fileLoader.xhr.send( formData );

			if( textResourceSubscription ) {
				textResourceSubscription.unsubscribe();
			}

			// Prevented the default behavior.
			evt.stop();
		}
	}
} );
