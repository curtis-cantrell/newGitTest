ace.define("ace/snippets/jsx",["require","exports","module"],function(e,t,n){"use strict";t.snippetText="",t.scope="jsx"});
                (function() {
                    ace.require(["ace/snippets/jsx"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            