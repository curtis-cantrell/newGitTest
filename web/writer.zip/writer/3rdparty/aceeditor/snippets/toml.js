ace.define("ace/snippets/toml",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="toml"});                (function() {
                    ace.require(["ace/snippets/toml"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            