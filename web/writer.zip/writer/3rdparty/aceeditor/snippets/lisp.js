ace.define("ace/snippets/lisp",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="lisp"});                (function() {
                    ace.require(["ace/snippets/lisp"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            