CKEDITOR.plugins.add( 'metadata', {
	lang: 'en,fr,de,es,fi,ja,nl,pt-br,ru',
	init: function( editor ) {
		var pluginName = 'metadata';
		editor.addCommand( pluginName, new CKEDITOR.dialogCommand( 'metadataDialog' ) );
		editor.ui.addButton( pluginName, {
			label   : editor.lang.metadata.toolbarButtonTitle,
			command : pluginName,
			disabled: true,
			icon    : CKEDITOR.plugins.getPath( pluginName ) + 'images/insert_metadata.png'
		} );

		var pluginDirectory = this.path;
		CKEDITOR.dialog.add( 'metadataDialog', pluginDirectory + 'dialogs/metadata.js' );

		editor.on( 'instanceReady', function( evt ) {
			var editor = evt.editor;

			// always deactivate metadata plugin first
			editor.getCommand( pluginName ).disable();

			var metadataObservable = editor.config.ccm.metadataObservable;
			if ( metadataObservable ) {
				metadataObservable.subscribe( function() {
					editor.getCommand( pluginName ).enable();
				}, function() {
					editor.getCommand( pluginName ).disable();
				} );
			}
		} );
	}
} );
