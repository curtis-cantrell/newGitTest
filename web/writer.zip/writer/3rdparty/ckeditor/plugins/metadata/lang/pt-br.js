CKEDITOR.plugins.setLang( 'metadata', 'pt-br',
    {
		insertButtonTitle: 'Inserir',
		toolbarButtonTitle : 'Inserir/Editar metadados',
		dialogHeaderTitle : 'Inserir metadados',
		errorMessage : 'Erro: não foi possível recuperar metadados do ServiceGateway.',
		propertiesTitle : "Propriedades"
    }
);