CKEDITOR.plugins.setLang( 'metadata', 'ja',
    {
		insertButtonTitle: '挿入',
		toolbarButtonTitle : 'メタデータの挿入/編集',
		dialogHeaderTitle : 'メタデータの挿入',
		errorMessage : 'エラー: サービスゲートウェイからメタデータを取得できません。',
		propertiesTitle : "プロパティ"
    }
);