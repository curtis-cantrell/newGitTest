﻿CKEDITOR.dialog.add( 'metadataDialog', function( editor ) {

	function openMetadataModel() {
		if ( !(editor.config.ccm.sgwURL) ) {
			throw new Error( 'Metadata Plugin: Missing configuration value' )
		}

		var metadataObservable = editor.config.ccm.metadataObservable;

		if ( metadataObservable ) {
			metadataObservable.subscribe( function( metadata ) {
				handleResult( metadata );
			}, function( error ) {
				$( '#metadatacontent' ).html( editor.lang.metadata.errorMessage );
			} );
		} else {
			var metadataType = editor.config.ccm.messageComplextype;
			if ( !metadataType ) {
				throw new Error( 'Metadata Plugin: Cannot retrieve metadata, missing messageComplexType' );
			}
			var headers = {
				'Content-Type': 'application/json',
				'OTDSTicket'  : editor.config.ccm.otdsTicket
			};
			var url = editor.config.ccm.sgwURL + '/metamodels/' + metadataType + '/flat';

			$.ajax( {
				url    : url,
				headers: headers,
				success: function( data ) {
					handleResult( data.data );
				},
				error  : function() {
					$( '#metadatacontent' ).html( editor.lang.metadata.errorMessage );
				}
			} );
		}
	}

	function handleResult( result ) {
		var focusableChildElements;
		var metadataSelected = false;
		$( '#metadatacontent' ).html( buildHtml( result ) );

		function ensureAllChildElementsAreFocusTrapped() {
			var selector = 'button:not([disabled]), [tabindex]:not([tabindex="-1"])';
			if ( focusableChildElements ) {
				var currentlyFocusableChildElements = $( selector, $( '.cke_dialog' ) );
				if ( currentlyFocusableChildElements.is( focusableChildElements ) ) {
					return;
				}
				focusableChildElements.off( 'keydown', handleKeyDown );
			}
			focusableChildElements = $( selector, $( '.cke_dialog' ) );
			focusableChildElements.off( 'keydown', handleKeyDown );
			focusableChildElements.on( 'keydown', handleKeyDown );
		}

		function handleKeyDown( event ) {
			if ( event.which === 9 ) { // TAB
				ensureAllChildElementsAreFocusTrapped();
				var visibleElements = focusableChildElements.filter( ':visible' );
				if ( event.shiftKey ) { // TAB backwards
					if ( visibleElements.first().is( event.target ) ) {
						event.preventDefault();
						visibleElements.last().focus();
					}
					event.stopPropagation();
				} else {
					if ( visibleElements.last().is( event.target ) ) {
						event.preventDefault();
						visibleElements.first().focus();
					}
					event.stopPropagation();
				}
			} else if ( event.which == 13 || event.which == 32 ) {
				if ( $( event.target ).hasClass( 'metadata-label' ) ) {
					event.stopPropagation();
					metadataSelected = !metadataSelected;
					toggleSelectedProperty( event.target );
					if ( metadataSelected ) {
						$( '.insert-metadata-enabled' ).attr( 'tabindex', '0' );
					} else {
						$( '.insert-metadata-disabled' ).attr( 'tabindex', -1 );
					}
				} else if ( $( event.target ).hasClass( 'metadata-type-item' ) ) {
					$( '.metadata-type-item' ).parent().removeClass( 'active' );
					var target$ = $( this );
					target$.parent().addClass( 'active' );
					var selectedItem = target$.attr( 'data-type-id' );
					$( '#' + selectedItem )[0].scrollIntoView();
					var ele = (($( '#' + selectedItem )).find( '.metadata-label' )).first();
					ele.focus();
				}
			}
		}

		//Adding 0px outline on mousedown to override focus class
		$( '.metadata-label' ).on( 'mousedown', function( event ) {
			$( event.currentTarget ).css( 'outline', '0px' );
		} );
		$( '.metadata-type-item' ).on( 'mousedown', function( event ) {
			$( event.currentTarget ).css( 'outline', '0px' );
		} );
		//Removing outline on blur
		$( '.metadata-type-item' ).on( 'blur', function( event ) {
			$( event.currentTarget ).css( 'outline', '' );
		} );
		$( '.metadata-label' ).on( 'blur', function( event ) {
			$( event.currentTarget ).css( 'outline', '' );
		} );

		$( document ).ready( function() {
			// tabbed navigation clickhandler
			var tabItem$ = $( '.metadata-type-item' );
			$( '.metadata-label' ).attr( 'tabindex', 0 );
			$( '.cke_dialog_ui_button_cancel' ).attr( 'tabindex', 0 );
			$( '.insert-metadata-disabled' ).attr( 'tabindex', -1 );

			tabItem$.attr( 'tabindex', 0 );
			tabItem$.on( 'click', function( event ) {
				if ( this === event.target ) {
					event.preventDefault();
					tabItem$.parent().removeClass( 'active' );
					var target$ = $( this );
					target$.parent().addClass( 'active' );
					var selectedItem = target$.attr( 'data-type-id' );
					$( '#' + selectedItem )[0].scrollIntoView();
				}
			} );
			// property select handler
			$( '.metadata-label' ).on( 'click', function( event ) {
				if ( event.type === 'click' ) {
					metadataSelected = !metadataSelected;
					toggleSelectedProperty( this );
					if ( metadataSelected ) {
						$( '.insert-metadata-enabled' ).attr( 'tabindex', '0' );
					} else {
						$( '.insert-metadata-disabled' ).attr( 'tabindex', -1 );
					}
				}
			} );
			ensureAllChildElementsAreFocusTrapped();
		} );
	}

	function buildHtml( data ) {
		var dialogHtml = '<div><div class="metadata-content-header"><div class="metadata-basename"></div><div class="metadata-types-nav"><ul class="nav nav-tabs"></ul></div></div><div id="propertiesList" class="metadata-typeslist"></div></div>';
		var dialogHtml$ = $( dialogHtml );
		$( '.metadata-basename', dialogHtml$ ).text( editor.lang.metadata.propertiesTitle );

		var typesList$ = $( 'ul', dialogHtml$ );
		var propertiesList$ = $( '#propertiesList', dialogHtml$ );

		for ( var dataCounter = 0; dataCounter < data.length; dataCounter++ ) {
			var typeItemTab$ = $( '<li><a class="metadata-type-item" href="" data-type-id="" tabindex="0"></a></li>' );
			if ( dataCounter === 0 ) {
				typeItemTab$.addClass( 'active' );
			}
			var currentData = data[dataCounter];
			var typeId = currentData.id;
			var typeName = currentData.name;
			$( 'a', typeItemTab$ ).attr( 'data-type-id', typeId ).text( typeName );
			typesList$.append( typeItemTab$ );

			var typeItem$ = $( '<div id="" class="metadata-title"></div>' );
			typeItem$.attr( 'id', typeId ).text( typeName );

			if ( currentData.properties && currentData.properties.length > 0 ) {
				var propertyRowItem$ = $( '<div class="row"><div class="col-xs-6 col-sm-6 col-md-6 col-lg-6"></div></div>' );
				var propertyColumnItem$ = $( 'div', propertyRowItem$ );

				for ( var propertyCounter = 0; propertyCounter < currentData.properties.length; propertyCounter++ ) {
					var currentProperty = currentData.properties[propertyCounter];

					if ( propertyCounter === Math.ceil( currentData.properties.length / 2 ) && propertyCounter > 1 ) {
						// add another column
						propertyColumnItem$ = $( '<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">' );
						propertyRowItem$.append( propertyColumnItem$ );
					}
					var propertyItem$ = $( '<div class="metadata-property"><span class="metadata-label" data-metadataId="" tabindex="0"></span></div>' );
					$( '.metadata-label', propertyItem$ ).attr( 'data-metadataId', currentProperty.id ).text( currentProperty.name );
					propertyColumnItem$.append( propertyItem$ );
					propertyRowItem$.append( propertyColumnItem$ );
				}
				typeItem$.append( propertyRowItem$ );
			}
			propertiesList$.append( typeItem$ );
		}
		return dialogHtml$.html();
	}

	function toggleSelectedProperty( propertyElem ) {
		var insertButton = CKEDITOR.dialog.getCurrent().getButton( 'InsertMetadata' );
		var insertButton$ = $( '#' + insertButton.domId );
		if ( $( propertyElem ).hasClass( 'metadata-selected' ) ) {
			insertButton.disable();
			insertButton$.removeClass( 'insert-metadata-enabled' );
			insertButton$.addClass( 'insert-metadata-disabled' );
			$( propertyElem ).removeClass( 'metadata-selected' );
		} else {
			insertButton.enable();
			insertButton$.removeClass( 'insert-metadata-disabled' );
			insertButton$.addClass( 'insert-metadata-enabled' );
			$( '.metadata-label' ).removeClass( 'metadata-selected' );
			$( propertyElem ).addClass( 'metadata-selected' );
		}
	}

	return {
		title    : editor.lang.metadata.dialogHeaderTitle,
		resizable: CKEDITOR.DIALOG_RESIZE_NONE,
		height   : 480,
		width    : 752, //44em UXD spec metadata content area + dialog padding
		contents : [{
			id      : 'general', // not localised as not displayed in UI
			label   : 'Metadata Properties',
			elements: [{
				id    : 'MetadataProperties',
				type  : 'html',
				html  : '<div id="metadatacontent" class="metadata-content container-fluid"></div>',
				onShow: function() {

					var dialog = CKEDITOR.dialog.getCurrent();
					dialog.disableButton( 'InsertMetadata' );
					$( '#' + dialog.getButton( 'InsertMetadata' ).domId ).addClass( 'insert-metadata-disabled' ).removeClass( 'insert-metadata-enabled' );
					openMetadataModel();
				},
				onLoad: function() {
					// deactivate CKEditor reset style to allow proper usage of projects bootstrap styles in dialog
					CKEDITOR.dialog.getCurrent().getElement().removeClass( 'cke_reset_all' );
				}
			}]
		}],
		buttons  : [{
			id       : 'InsertMetadata',
			label    : editor.lang.metadata.insertButtonTitle,
			type     : 'button',
			title    : editor.lang.metadata.insertButtonTitle,
			className: 'insert-metadata-disabled',
			disabled : true,
			onClick  : function() {
				var selectedMetadata$ = $( '.metadata-selected' );
				var propertyName = selectedMetadata$.text();
				var propertyGUID = selectedMetadata$.attr( 'data-metadataId' );
				var html = '<code class="strsmd" title="strsmd:' + propertyGUID + '" contenteditable="false">' + propertyName + '</code>';
				var newElement = CKEDITOR.dom.element.createFromHtml( html, editor.document );
				editor.insertElement( newElement );
				var dialog = CKEDITOR.dialog.getCurrent();
				dialog.disableButton( 'InsertMetadata' );
				$( '#' + dialog.getButton( 'InsertMetadata' ).domId ).addClass( 'insert-metadata-disabled' ).removeClass( 'insert-metadata-enabled' );
				$( 'li > span' ).removeClass( 'selected-metadata' );
				dialog._.buttons.cancel.click();
			}
		}, CKEDITOR.dialog.cancelButton]
	};
} );
