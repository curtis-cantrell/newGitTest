/*jshint unused:true*/

var empowerPackage = {
  "version": "16.6.0.33533"
  };


/*jshint unused:false*/

/**
 * @fileoverview The Empower editor!
 * @suppress {globalThis}
 */