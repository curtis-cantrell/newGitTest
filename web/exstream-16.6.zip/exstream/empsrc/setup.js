/*global hermes:true */
/*global module:true */
/*global UserLogic:true */
/*global LiteralValue:true */

/*jshint sub:true*/

/** @const */
window['hermes'] = { compiler : {}, formula : {}, functions : {}, rules : {}, exporters: { } };
window.UserLogic = {};
window.LiteralValue = {};
