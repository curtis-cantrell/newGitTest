Hungarian Hunspell dictionaries version 1.6.1 with morphological data

Requirements: Hunspell 1.1.3 or newer

License

GPL 2.0/LGPL 2.1/MPL 1.1 tri-license

The contents of this software may be used under the terms of
the GNU General Public License Version 2 or later (the "GPL"), or
the GNU Lesser General Public License Version 2.1 or later (the "LGPL",
see COPYING.LGPL) or (excepting the LGPLed GNU gettext library in the
intl/ directory) the Mozilla Public License Version 1.1 or later
(the "MPL", see COPYING.MPL).

Software distributed under these licenses is distributed on an "AS IS" basis,
WITHOUT WARRANTY OF ANY KIND, either express or implied. See the licences
for the specific language governing rights and limitations under the licenses.

2010 (c) László Németh & Ferenc Godó

Home: http://magyarispell.sf.net
