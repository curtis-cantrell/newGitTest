Myspell dictionary
------------------

Language: Norwegian Bokm�l (nb NO)
Origin:   Generated from the spell-norwegian source v2.0.10
License:  GNU General Public license
Author:   The spell-norwegian project, <URL:https://alioth.debian.org/projects/spell-norwegian/>

DICT nb NO nb_NO
