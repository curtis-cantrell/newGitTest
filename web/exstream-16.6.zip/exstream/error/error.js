function showErrorMessage() {
	const cookieKey = 'OT_CC_ERROR_CODE';
	const cookieValue = getCookieValue( cookieKey );
	const errorMessage = getErrorMessage( cookieValue );
	const element = document.getElementById( 'message' );
	element.innerText = errorMessage;
	deleteCookie( cookieKey );
}

function getCookieValue( key ){
	let result = null;
	const cookieArray = ( window.document.cookie || '' ).split( '; ' );

	cookieArray.forEach( function( cookie ) {
		const pos = cookie.indexOf( '=' );
		if ( pos <= 0 ) {
			return;
		}

		const name = safeDecode( cookie.substring( 0, pos ) );
		const value = safeDecode( cookie.substring( pos + 1 ) );
		if ( !value || name !== key ) {
			return;
		}

		result = value;
	} );
	return result;
}

function safeDecode( value ) {
	try {
		return decodeURIComponent( value );
	} catch ( e ) {
		return value;
	}
}

function getErrorMessage( errorCode ) {
	switch ( errorCode ) {
		case 'APPLICATION.ERROR_TENANT_OR_DOMAIN_MISSING':
			return MESSAGES.DESIGNER.ERRORS.INVALID_URL_PARAMS;
		case 'APPLICATION.ERROR_INVALID_TENANT_INFO':
			return MESSAGES.DESIGNER.ERRORS.INVALID_TENANT_INFO;
		default:
			return MESSAGES.DESIGNER.ERRORS.GENERIC_ERROR;
	}
}

function deleteCookie( key, path ) {
	document.cookie = encodeURIComponent( key ) + '=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=' + (path || '/');
}

function getLocaleString() {
	var temp = "";
	if( navigator.languages != undefined ) {
			temp = navigator.languages[0];
	} else {
			temp = navigator.language || navigator.userLanguage;
	}
	temp = temp.split("-")[0];
	switch( temp ) {
			case "zh":
					return "zh_CN";
			case "pt":
					return "pt_BR";
			case "nl":
					return "nl_NL";
			case "ja":
					return "ja_JP";
			case "fr":
					return "fr_FR";
			case "es":
					return "es_MX";
			case "de":
					return "de_DE";
			default:
					return "en_US";
	}
}

var locale = "en_US";
var localeWasSet = false;
var url = window.location.href.split( "?" );
if ( url.length > 1 ) {
	queryParams = url[ 1 ].split( "&" );
	queryParams.forEach(function(param) {
			if(param.indexOf("locale") >= 0)
			{
					locale = param.split("=")[1];
					localeWasSet = true;
			}
	});
}
if(!localeWasSet) {
	locale = getLocaleString();
}
var messageFileUrl = "empsrc/locale/"+locale+"/Messages.min.json";
var messageXHR = new XMLHttpRequest();
messageXHR.onload = function() {
	window.MESSAGES = JSON.parse(messageXHR.responseText);
	showErrorMessage();
};
messageXHR.open("GET", messageFileUrl, false);
messageXHR.send();
