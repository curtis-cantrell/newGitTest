/**
 * Created by dreil on 16.05.17.
 */
var availableLanguages = ['de', 'es', 'fi', 'fr', 'ja', 'nl', 'pt', 'ru', 'sv', 'zh'];
var locationSearchRegex = /[\?&]language=([a-z]{2}(?:[-_][a-z]{2,3})?)?/i;
var languageConfiguration = { 'en': { 'inline': 'inline.ee17472045491e930cd1.bundle.js', 'polyfills': 'polyfills.c582d537a9a0dce8cc65.bundle.js', 'main': 'main.f57bcbe54f01bc252b44.bundle.js', 'styles': 'styles.0a2bd9adb1158da1b1fb.bundle.css', 'vendor': 'vendor.10c5f684bfba34521de1.bundle.js' }, 'de': { 'inline': 'inline.699aa972c9f1a9d186c2.de.bundle.js', 'main': 'main.26c9f983c72b881b955e.de.bundle.js', 'polyfills': 'polyfills.c582d537a9a0dce8cc65.de.bundle.js', 'styles': 'styles.0a2bd9adb1158da1b1fb.de.bundle.css', 'vendor': 'vendor.6ec02098f311a3333a8a.de.bundle.js' }, 'es': { 'inline': 'inline.9df19e57c1ef380f0465.es.bundle.js', 'main': 'main.0cb596fb925d929e172e.es.bundle.js', 'polyfills': 'polyfills.c582d537a9a0dce8cc65.es.bundle.js', 'styles': 'styles.0a2bd9adb1158da1b1fb.es.bundle.css', 'vendor': 'vendor.3f56032930ff4f5047cd.es.bundle.js' }, 'fi': { 'inline': 'inline.398c7e5fc30f1423b9a2.fi.bundle.js', 'main': 'main.cbdd70433b1b45abc8bb.fi.bundle.js', 'polyfills': 'polyfills.c582d537a9a0dce8cc65.fi.bundle.js', 'styles': 'styles.0a2bd9adb1158da1b1fb.fi.bundle.css', 'vendor': 'vendor.a2d3c836d4793454e5cc.fi.bundle.js' }, 'fr': { 'inline': 'inline.bbb3a022ddb01f697e6d.fr.bundle.js', 'main': 'main.8b1c349409141722a7ff.fr.bundle.js', 'polyfills': 'polyfills.c582d537a9a0dce8cc65.fr.bundle.js', 'styles': 'styles.0a2bd9adb1158da1b1fb.fr.bundle.css', 'vendor': 'vendor.aaaa0dd279ce805ca198.fr.bundle.js' }, 'ja': { 'inline': 'inline.ad6680210ad019de183d.ja.bundle.js', 'main': 'main.732e955c0937718887b0.ja.bundle.js', 'polyfills': 'polyfills.c582d537a9a0dce8cc65.ja.bundle.js', 'styles': 'styles.0a2bd9adb1158da1b1fb.ja.bundle.css', 'vendor': 'vendor.ae3291a328ee8981e127.ja.bundle.js' }, 'nl': { 'inline': 'inline.c12880cf847dee7291c3.nl.bundle.js', 'main': 'main.4c4124b9d8b896318bc8.nl.bundle.js', 'polyfills': 'polyfills.c582d537a9a0dce8cc65.nl.bundle.js', 'styles': 'styles.0a2bd9adb1158da1b1fb.nl.bundle.css', 'vendor': 'vendor.2d00f52628056658b3dc.nl.bundle.js' }, 'pt': { 'inline': 'inline.fe1a1bff3064d6bdde1c.pt.bundle.js', 'main': 'main.0be71c53dc8b2b62d6fc.pt.bundle.js', 'polyfills': 'polyfills.c582d537a9a0dce8cc65.pt.bundle.js', 'styles': 'styles.0a2bd9adb1158da1b1fb.pt.bundle.css', 'vendor': 'vendor.07a1e60a9c72b168ecf4.pt.bundle.js' }, 'ru': { 'inline': 'inline.04abcb3f2a301f665821.ru.bundle.js', 'main': 'main.0c90b09f80c288e9dd14.ru.bundle.js', 'polyfills': 'polyfills.c582d537a9a0dce8cc65.ru.bundle.js', 'styles': 'styles.0a2bd9adb1158da1b1fb.ru.bundle.css', 'vendor': 'vendor.0daa19f212d3dcb7e1d0.ru.bundle.js' }, 'sv': { 'inline': 'inline.3ad2f499cd1032616eff.sv.bundle.js', 'main': 'main.2d49771f6a2a54e60ce4.sv.bundle.js', 'polyfills': 'polyfills.c582d537a9a0dce8cc65.sv.bundle.js', 'styles': 'styles.0a2bd9adb1158da1b1fb.sv.bundle.css', 'vendor': 'vendor.22792a1ddd6c69df6a00.sv.bundle.js' }, 'zh': { 'inline': 'inline.cf2b4aa9c8fa90f07a42.zh.bundle.js', 'main': 'main.3df735bfab64090212a4.zh.bundle.js', 'polyfills': 'polyfills.c582d537a9a0dce8cc65.zh.bundle.js', 'styles': 'styles.0a2bd9adb1158da1b1fb.zh.bundle.css', 'vendor': 'vendor.c760244de8ecb4607e56.zh.bundle.js' } };
function languageSelector() {
    var selectedLanguage = '';
    var fallbackLanguage = '';
    var urlLanguageMatch = locationSearchRegex.exec(location.search) || locationSearchRegex.exec(location.hash);
    if (urlLanguageMatch && urlLanguageMatch[1]) {
        selectedLanguage = urlLanguageMatch[1].toLowerCase().replace('-', '_');
        fallbackLanguage = selectedLanguage.length > 2 ? selectedLanguage.substr(0, 2) : selectedLanguage;
    }
    var chosenLanguage = 'en';
    if (availableLanguages.indexOf(selectedLanguage) > -1) {
        chosenLanguage = selectedLanguage;
    }
    else if (availableLanguages.indexOf(fallbackLanguage) > -1) {
        chosenLanguage = fallbackLanguage;
    }
    console.log('Language selected: ' + chosenLanguage);
    $('html').attr('lang', chosenLanguage);
    var body$ = $('body');
    // styles and polyfills are independent of the UI language, so always using
    // the base files and not deploying duplicate files
    body$.append('<link href="' + languageConfiguration['en'].styles + '" rel="stylesheet"/>');
    var scripts$ = $('<div/>');
    scripts$.append('<script type="text/javascript" src="' + languageConfiguration[chosenLanguage].inline + '"></script>');
    scripts$.append('<script type="text/javascript" src="' + languageConfiguration['en'].polyfills + '"></script>');
    scripts$.append('<script type="text/javascript" src="' + languageConfiguration[chosenLanguage].vendor + '"></script>');
    scripts$.append('<script type="text/javascript" src="' + languageConfiguration[chosenLanguage].main + '"></script>');
    // <link href="styles.9c51c5c1cc327f939f84.bundle.css" rel="stylesheet"/>
    body$.append(scripts$.children());
}
languageSelector();
