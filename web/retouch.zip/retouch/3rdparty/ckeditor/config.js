/**
 * @license Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here.
	// For complete reference see:
	// http://docs.ckeditor.com/#!/api/CKEDITOR.config

	// The toolbar groups arrangement, optimized for a single toolbar row.
	config.toolbarGroups = [{
		name  : 'document',
		groups: ['mode', 'document', 'doctools']
	}, {
		name  : 'clipboard',
		groups: ['clipboard', 'undo']
	}, {
		name  : 'editing',
		groups: ['find', 'selection', 'spellchecker']
	}, {name: 'forms'}, {
		name  : 'basicstyles',
		groups: ['basicstyles', 'cleanup']
	}, {
		name  : 'paragraph',
		groups: ['list', 'indent', 'blocks', 'align', 'bidi']
	}, {name: 'links'}, {name: 'insert'}, {name: 'styles'}, {name: 'colors'}, {name: 'tools'}, {name: 'others'}, {name: 'about'}];

	config.allowedContent = {
		// Allow all elements, all attributes, all classes and styles
		$1: {
			elements  : CKEDITOR ? CKEDITOR.dtd : null,
			attributes: true,
			classes   : true,
			styles    : true
		}
	};

	config.colorButton_enableAutomatic = true;
	config.colorButton_colorsPerRow = 4;
	config.colorButton_colors = 'black/000000,111B58,2E3D98,09BCEF,EA0A8E,FF6200,white/FFFFFF';

	config.filebrowserImageBrowseUrl = '/casbrowser/#/tenant/' + config.ccm.tenant + '/domain/' + config.ccm.domain;
	config.filebrowserImageUploadUrl = '/resources?type=image&lock=false&guid_format=false';

	config.fontSize_sizes = '8/8pt;9/9pt;10/10pt;11/11pt;12/12pt;14/14pt;16/16pt;18/18pt;20/20pt;22/22pt;24/24pt;26/26pt;28/28pt;36/36pt;48/48pt;72/72pt';

	config.stylesSet = [{
		name   : '1 Heading',
		element: 'h1',
		styles : {
			'-stl-list-counter': 'headings',
			'-stl-list-mask'   : '%0!1\\9',
			'-stl-list-level'  : '0'
		}
	}, {
		name   : '1.1 Heading',
		element: 'h2',
		styles : {
			'-stl-list-counter': 'headings',
			'-stl-list-mask'   : '%0!1.%1!1\\9',
			'-stl-list-level'  : '1'
		}
	}, {
		name   : '1.1.1 Heading',
		element: 'h3',
		styles : {
			'-stl-list-counter': 'headings',
			'-stl-list-mask'   : '%0!1.%1!1.%2!1\\9',
			'-stl-list-level'  : '2'
		}
	}];

	// Explicitly disallow script tags
	config.disallowedContent = 'script';

	// The default plugins included in the basic setup define some buttons that
	// are not needed in a basic editor. They are removed here.
	config.removeButtons = 'Anchor,Strike,Subscript,Superscript';

	// Dialog windows are also simplified.
	config.removeDialogTabs = 'link:advanced';

	// Adds preinstalled plugins
	config.extraPlugins += ',metadata';
	config.extraContentsCss = '/css/plugin.css';

	// Remove some preinstalled plugins for most simple editing experience
	config.removePlugins += ',bidi,justify,language';
};
