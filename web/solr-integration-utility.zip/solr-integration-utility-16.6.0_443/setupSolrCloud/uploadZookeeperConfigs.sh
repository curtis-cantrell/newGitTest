#!/bin/bash
echo [INFO] **********************************************************************************************************************
echo [INFO] Solr setup script for OpenText Exstream platform 
echo [INFO] Note: Make sure you stop the ServiceGateway service before running this script, trigger start after completion
echo [INFO] **********************************************************************************************************************
if [ -n "$JAVA_HOME" ]; then
    echo "[INFO] \$JAVA_HOME is set to $JAVA_HOME";
else
    echo "[ERROR] Essential environment variable JAVA_HOME is not set, exiting"
	exit 1
fi
export STEPS=3
source setPropertiesCloud.sh
cd $CURRENT_DIR
echo [INFO] [1/$STEPS]  Creating new path for solr in zookeeper --------------
cd "$SOLR_DIR/bin"
./solr zk mkroot $ZOOKEEPERCHROOT -z "$ZOOKEEPERHOSTS"
echo [INFO] [2/$STEPS]Updating solr.xml in zookeeper -----------------------
export SOLRXMLPATH=$CURRENT_DIR/../scaffold/conf/solr.xml
./solr zk cp file:$SOLRXMLPATH zk:/solr.xml -z "$ZKHOSTSOLRPATH"
cd "$SOLR_DIR/server/scripts/cloud-scripts"
./zkcli.sh -zkhost "$ZOOKEEPERHOSTS" -cmd updateacls $ZOOKEEPERCHROOT
cd $CURRENT_DIR
echo [INFO] [3/$STEPS] Uploading resources, logs and collector configuration to zookeeper -------------
cd $CURRENT_DIR
export CORENAMESEPARATOR=_
export CORENAMECLOUD=cloud
while read p; do
	cd "$SOLR_DIR/bin"
	cp -r $CURRENT_DIR/../out/$p$CORENAMESEPARATOR$CORENAMECLOUD "$SOLR_DIR/server/solr/configsets"
  ./solr zk upconfig -z "$ZKHOSTSOLRPATH" -n $p -d $p$CORENAMESEPARATOR$CORENAMECLOUD
done < ../out/corenames.txt
cd $CURRENT_DIR