#!/bin/bash
export CURRENT_DIR=`pwd`
export SOLR_DIR=/opt/solr/solrNode1/solr-6.6.0
export MGW_APPS_DIR=/opt/exstreamsetup/root/applications
export SOLR_SERVER_DIR=$SOLR_DIR/server
export ZOOKEEPERHOSTS=localhost:2181
export ZOOKEEPERCHROOT=/solr
export ZKHOSTSOLRPATH=$ZOOKEEPERHOSTS$ZOOKEEPERCHROOT
export SOLRHOST=localhost
export SOLRPORT=8984
export NUMBEROFSHARDS=2
export NUMBEROFREPLICA=2
export MAXSHARDSPERNODE=2
export SOLRUSERNAME=
export SOLRPASSWORD=
export ZKUSERNAME=
export ZKPASSWORD=

