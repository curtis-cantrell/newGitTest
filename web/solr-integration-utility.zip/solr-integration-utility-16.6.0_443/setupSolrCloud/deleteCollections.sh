#!/bin/bash
echo [INFO] **********************************************************************************************************************
echo [INFO] Solr setup script for OpenText Exstream platform 
echo [INFO] Note: Make sure you stop the ServiceGateway service before running this script, trigger start after completion
echo [INFO] **********************************************************************************************************************
if [ -n "$JAVA_HOME" ]; then
    echo "[INFO] \$JAVA_HOME is set to $JAVA_HOME";
else
    echo "[ERROR] Essential environment variable JAVA_HOME is not set, exiting"
	exit 1
fi
export STEPS=2
source setPropertiesCloud.sh
echo "[INFO] [1/$STEPS] Starting solr instance"
"$SOLR_DIR/bin/solr" start -p $SOLRPORT -force -c -s $SOLR_SERVER_DIR -z "$ZKHOSTSOLRPATH"
cd $CURRENT_DIR
echo "[INFO] [2/$STEPS] Deleting existing collections"
while read p; do
  cd "$CURRENT_DIR/../scaffold/bin"
  sh solr.collections.setup.sh DELETE $SOLRHOST $SOLRPORT $p $NUMBEROFSHARDS $NUMBEROFREPLICA $MAXSHARDSPERNODE $SOLRUSERNAME $SOLRPASSWORD
done < ../out/corenames.txt
cd $CURRENT_DIR