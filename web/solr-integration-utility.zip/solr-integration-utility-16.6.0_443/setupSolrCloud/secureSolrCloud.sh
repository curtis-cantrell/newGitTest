#!/bin/bash
echo "[INFO] ***********************************************************************"
echo "[INFO] Secure solr cores - OpenText Exstream platform "
echo "[INFO] Note: Make sure you stop the ServiceGateway service before running this"
echo "[INFO] ***********************************************************************"
if [ -n "$JAVA_HOME" ]; then
    echo "[INFO] \$JAVA_HOME is set to $JAVA_HOME";
else
    echo "[ERROR] Essential environment variable JAVA_HOME is not set, exiting"
	exit 1
fi
source setPropertiesCloud.sh
cd $CURRENT_DIR
echo Updating security.json in zookeeper -----------------------
export SOLRSECURITYJSONPATH=$CURRENT_DIR/../scaffold/conf/security/security.json
cd "$SOLR_DIR/bin"
./solr zk cp file:$SOLRSECURITYJSONPATH zk:/security.json -z "$ZKHOSTSOLRPATH"
cd "$CURRENT_DIR/../scaffold/bin"
echo "[INFO] Enabling solr security"
sh solr.security.setup.sh $SOLRHOST $SOLRPORT $SOLRUSERNAME $SOLRPASSWORD
cd $CURRENT_DIR