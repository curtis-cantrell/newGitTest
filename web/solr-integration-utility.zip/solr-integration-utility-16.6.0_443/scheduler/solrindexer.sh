CURRENT_DIR=`pwd`
echo $CURRENT_DIR
# Used to report errors before exiting the script
SCRIPT_ERROR=
NO_USER_PROMPT=0

INDEXER_CREATE_ALL=
SOLR_INDEXER_TENANT=
SOLR_INDEXER_TENANT_VAL=

# Verify Java is available

if [ -n "$JAVA_HOME" ]; then
	JAVA=$JAVA_HOME\bin\java
else
	SCRIPT_ERROR="Java 1.8 or later is required to run Solr. Java not found"
	echo $SCRIPT_ERROR
	exit 1
fi

FIRST_ARG=$1
HELP_COMMAND="-help"
CREATE_COMMAND="create"
DELETE_COMMAND="delete"

if [ "$FIRST_ARG" == "$HELP_COMMAND" ] || [ "$FIRST_ARG" == "" ]
then
	echo .
	echo Usage: solrIndexer COMMAND OPTIONS
	echo        where COMMAND is one of: create, delete
	echo
	echo -- Create scheduler service for all tenants example
	echo 		solrindexer create -all
	echo -- Create scheduler service for specific tenant example
	echo 		solrindexer create - tenant DF6E11A5-BADE-3E4A-9381-FD3B5B51FE04
	echo -- Delete scheduler service for all tenants example
	echo 		solrindexer delete -all
	echo -- Delete scheduler service for specific tenant example
	echo 		solrindexer delete - tenant DF6E11A5-BADE-3E4A-9381-FD3B5B51FE04
	echo
	echo Pass -help after any COMMAND to see command-specific usage information,
	echo   such as:    solrindexer create -help or solrindexer delete -help
	echo
elif [ "$FIRST_ARG" == "$CREATE_COMMAND" ] 
then
	echo Configuring solr scheduler
	SECOND_ARG=$2
	if [ "$SECOND_ARG" == "" ] 
	then
		echo This command expects an option. Please check -help
	elif [ "$SECOND_ARG" == "-tenant" ]
	then
		
		THIRD_ARG=$3
		if [ "$THIRD_ARG" == "" ] 
		then
			echo This command expects an value. Please check -help
		else
			cd "$CURRENT_DIR/../scaffold/bin"
			sh scaffold.run.sh
			cd $CURRENT_DIR
			TENANTFOUND="0"
			while read p; do
				if [ "$THIRD_ARG" == "$p" ]
				then
					cd "$CURRENT_DIR/../scaffold/bin"
					sh schedulerservice_create.sh start $p
					cd $CURRENT_DIR
					TENANTFOUND="1"
					break
				fi
			done < ../out/tenantnames.txt
			if [ "$TENANTFOUND" == "0" ]
			then
				echo "ERROR: Specified tenant doesn't exist"
				echo "Available tenants are: "
				while read p; do
					echo $p
				done < ../out/tenantnames.txt
			fi
		fi
	elif [ "$SECOND_ARG" == "-all" ]
	then
		cd "$CURRENT_DIR/../scaffold/bin"
		sh scaffold.run.sh
		cd $CURRENT_DIR
		while read p; do
			cd "$CURRENT_DIR/../scaffold/bin"
			sh schedulerservice_create.sh start $p
			cd $CURRENT_DIR
		done < ../out/tenantnames.txt
	else
		echo Invalid command. Please check -help
	fi
elif [ "$FIRST_ARG" == "$DELETE_COMMAND" ] 
then
	echo Stopping solr scheduler
	SECOND_ARG=$2
	if [ "$SECOND_ARG" == "" ] 
	then
		echo This command expects an option. Please check -help
	elif [ "$SECOND_ARG" == "-tenant" ]
	then
		
		THIRD_ARG=$3
		if [ "$THIRD_ARG" == "" ] 
		then
			echo This command expects an value. Please check -help
		else
			cd "$CURRENT_DIR/../scaffold/bin"
			sh scaffold.run.sh
			cd $CURRENT_DIR
			TENANTFOUND="0"
			while read p; do
				if [ "$THIRD_ARG" == "$p" ]
				then
					cd "$CURRENT_DIR/../scaffold/bin"
					sh schedulerservice_create.sh stop $3
					cd $CURRENT_DIR
					TENANTFOUND="1"
					break
				fi
			done < ../out/tenantnames.txt
			if [ "$TENANTFOUND" == "0" ]
			then
				echo "ERROR: Specified tenant doesn't exist"
				echo "Available tenants are: "
				while read p; do
					echo $p
				done < ../out/tenantnames.txt
			fi
		fi
	elif [ "$SECOND_ARG" == "-all" ]
	then
		cd "$CURRENT_DIR/../scaffold/bin"
		sh scaffold.run.sh
		cd $CURRENT_DIR
		while read p; do
			cd "$CURRENT_DIR/../scaffold/bin"
			sh schedulerservice_create.sh stop $p
			cd $CURRENT_DIR
		done < ../out/tenantnames.txt
	else
		echo Invalid command. Please check -help
	fi
else
	echo .
	echo Usage: solrIndexer COMMAND OPTIONS
	echo        where COMMAND is one of: create, delete
	echo
	echo -- Create scheduler service for all tenants example
	echo 		solrindexer create -all
	echo -- Create scheduler service for specific tenant example
	echo 		solrindexer create - tenant DF6E11A5-BADE-3E4A-9381-FD3B5B51FE04
	echo -- Delete scheduler service for all tenants example
	echo 		solrindexer delete -all
	echo -- Delete scheduler service for specific tenant example
	echo 		solrindexer delete - tenant DF6E11A5-BADE-3E4A-9381-FD3B5B51FE04
	echo
	echo Pass -help after any COMMAND to see command-specific usage information,
	echo   such as:    solrindexer create -help or solrindexer delete -help
	echo
fi

