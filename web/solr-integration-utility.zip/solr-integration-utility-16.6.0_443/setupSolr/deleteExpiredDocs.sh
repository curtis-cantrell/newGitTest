#!/bin/bash
echo "[INFO] ***********************************************************************"
echo "[INFO] Delete expired docs from core - OpenText Exstream platform "
echo "[INFO] Note: Make sure you stop the ServiceGateway service before running this"
echo "[INFO] ***********************************************************************"
if [ -n "$JAVA_HOME" ]; then
    echo "[INFO] \$JAVA_HOME is set to $JAVA_HOME";
else
    echo "[ERROR] Essential environment variable JAVA_HOME is not set, exiting"
	exit 1
fi
source setProperties.sh
cd $CURRENT_DIR
"$SOLR_DIR/bin/solr" start -p $SOLRPORT -force
cd "$CURRENT_DIR/../scaffold/bin"
echo "[INFO] Deleting expired logs and collect"
sh solr.deleteexpireddocs.sh $SOLRHOST $SOLRPORT $SOLRUSERNAME $SOLRPASSWORD
cd $CURRENT_DIR