#!/bin/bash
echo [INFO] **********************************************************************************************************************
echo [INFO] Solr setup script for OpenText Exstream platform 
echo [INFO] Note: Make sure you stop the ServiceGateway service before running this script, trigger start after completion
echo [INFO] **********************************************************************************************************************
if [ -n "$JAVA_HOME" ]; then
    echo "[INFO] \$JAVA_HOME is set to $JAVA_HOME";
else
    echo "[ERROR] Essential environment variable JAVA_HOME is not set, exiting"
	exit 1
fi
export STEPS=2
source setProperties.sh
echo "[INFO] [1/$STEPS] Starting solr instance"
"$SOLR_DIR/bin/solr" start -p $SOLRPORT -force
cd $CURRENT_DIR
echo "[INFO] [2/$STEPS] Creating new cores"
while read p; do
  "$SOLR_DIR/bin/solr" create -c $p -d ../out/$p -force
done < ../out/corenames.txt
cd $CURRENT_DIR