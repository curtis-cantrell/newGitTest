#!/bin/bash
export CURRENT_DIR=`pwd`
export SOLR_DIR=/opt/solr/solr-6.6.0
export MGW_APPS_DIR=/opt/exstreamsetup/root/applications
export SOLRHOST=localhost
export SOLRPORT=8983
export SOLRUSERNAME=
export SOLRPASSWORD=