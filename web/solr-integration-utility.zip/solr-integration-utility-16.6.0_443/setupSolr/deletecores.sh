#!/bin/bash
if [ -n "$JAVA_HOME" ]; then
    echo "[INFO] \$JAVA_HOME is set to $JAVA_HOME";
else
    echo "[ERROR] Essential environment variable JAVA_HOME is not set, exiting"
	exit 1
fi
source setProperties.sh
echo [INFO] Starting Solr instance
cd $CURRENT_DIR
"$SOLR_DIR/bin/solr" start -p $SOLRPORT -force
echo [INFO] Removing the collected Solr cores
while read p; do
  "$SOLR_DIR/bin/solr" delete -c $p
done < ../out/corenames.txt

