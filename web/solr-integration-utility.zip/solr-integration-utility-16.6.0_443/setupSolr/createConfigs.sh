#!/bin/bash
echo [INFO] **********************************************************************************************************************
echo [INFO] Solr setup script for OpenText Exstream platform 
echo [INFO] Note: Make sure you stop the ServiceGateway service before running this script, trigger start after completion
echo [INFO] **********************************************************************************************************************
if [ -n "$JAVA_HOME" ]; then
    echo "[INFO] \$JAVA_HOME is set to $JAVA_HOME";
else
    echo "[ERROR] Essential environment variable JAVA_HOME is not set, exiting"
	exit 1
fi
export STEPS=4
source setProperties.sh
echo "[INFO] [1/$STEPS] Stopping solr server (if any)"
$SOLR_DIR/bin/solr stop -p $SOLRPORT 
echo "[INFO] [2/$STEPS] Copying dependency jars to solr runtime"
cp -r "$CURRENT_DIR/../jdbc-lib/." "$SOLR_DIR/dist/solrj-lib"
cp -r "$CURRENT_DIR/../transform/lib/ccm-logmessage-transformer.jar" "$SOLR_DIR/dist/solrj-lib"
echo "[INFO] [3/$STEPS] Starting solr server"
$SOLR_DIR/bin/solr start -p $SOLRPORT
cd "$CURRENT_DIR/../scaffold/bin"
echo "[INFO] [4/$STEPS] Preparing solr and dbconfigurations for resources, logs and collect workspaces"
sh scaffold.run.sh
cd $CURRENT_DIR