var availableLanguages = ['de', 'es', 'fi', 'fr', 'ja', 'nl', 'pt', 'ru', 'sv', 'zh'];
var locationSearchRegex = /[\?&]language=([a-z]{2}(?:[-_][a-z]{2,3})?)?/i;
var languageConfiguration = { 'en': { 'inline': 'inline.f0ab1c07fc5f699ff584.bundle.js', 'polyfills': 'polyfills.9a22720c747de39b8217.bundle.js', 'main': 'main.2ab272aa830ed9aa65e3.bundle.js', 'styles': 'styles.09e4280dcb798be8dd72.bundle.css', 'vendor': 'vendor.2f5a852fab5ca1e57449.bundle.js' }, 'de': { 'inline': 'inline.aa20a08ce6707e32faa3.de.bundle.js', 'main': 'main.5965ff049d34888b851f.de.bundle.js', 'polyfills': 'polyfills.9a22720c747de39b8217.de.bundle.js', 'styles': 'styles.09e4280dcb798be8dd72.de.bundle.css', 'vendor': 'vendor.390129cf2719995a2e9e.de.bundle.js' }, 'es': { 'inline': 'inline.c28813ec82311cbe1da3.es.bundle.js', 'main': 'main.5471b6675d3d7c8e3dbe.es.bundle.js', 'polyfills': 'polyfills.9a22720c747de39b8217.es.bundle.js', 'styles': 'styles.09e4280dcb798be8dd72.es.bundle.css', 'vendor': 'vendor.a0cd35774e3f7371c556.es.bundle.js' }, 'fi': { 'inline': 'inline.077e155e9c8ba5da65e1.fi.bundle.js', 'main': 'main.536aeadbe1dd3fe28765.fi.bundle.js', 'polyfills': 'polyfills.9a22720c747de39b8217.fi.bundle.js', 'styles': 'styles.09e4280dcb798be8dd72.fi.bundle.css', 'vendor': 'vendor.31d365bfafe5a0661bbe.fi.bundle.js' }, 'fr': { 'inline': 'inline.edcd009a35d753fe6f92.fr.bundle.js', 'main': 'main.109ff619b5cceab37fd9.fr.bundle.js', 'polyfills': 'polyfills.9a22720c747de39b8217.fr.bundle.js', 'styles': 'styles.09e4280dcb798be8dd72.fr.bundle.css', 'vendor': 'vendor.b94ab7cd1e8aa3c35782.fr.bundle.js' }, 'ja': { 'inline': 'inline.3cd5aabff6baf6cd7207.ja.bundle.js', 'main': 'main.591acf1f9995aa858397.ja.bundle.js', 'polyfills': 'polyfills.9a22720c747de39b8217.ja.bundle.js', 'styles': 'styles.09e4280dcb798be8dd72.ja.bundle.css', 'vendor': 'vendor.cfd9e5df638a5f678392.ja.bundle.js' }, 'nl': { 'inline': 'inline.8d6c3070ff44d6486bb3.nl.bundle.js', 'main': 'main.3129575cf5ce025341fa.nl.bundle.js', 'polyfills': 'polyfills.9a22720c747de39b8217.nl.bundle.js', 'styles': 'styles.09e4280dcb798be8dd72.nl.bundle.css', 'vendor': 'vendor.e890ac84f8f7dc7fc511.nl.bundle.js' }, 'pt': { 'inline': 'inline.c3b4495515d2dfec50f7.pt.bundle.js', 'main': 'main.06762a685f8ae71f7916.pt.bundle.js', 'polyfills': 'polyfills.9a22720c747de39b8217.pt.bundle.js', 'styles': 'styles.09e4280dcb798be8dd72.pt.bundle.css', 'vendor': 'vendor.837f883c16f672f5a927.pt.bundle.js' }, 'ru': { 'inline': 'inline.5cdaa9c49dfe485ac248.ru.bundle.js', 'main': 'main.82241e2c6aaceb4b7ea5.ru.bundle.js', 'polyfills': 'polyfills.9a22720c747de39b8217.ru.bundle.js', 'styles': 'styles.09e4280dcb798be8dd72.ru.bundle.css', 'vendor': 'vendor.2c901e36f1a94fab1a20.ru.bundle.js' }, 'sv': { 'inline': 'inline.790f673af86918c0131a.sv.bundle.js', 'main': 'main.946a1c4a4ad2e69f1359.sv.bundle.js', 'polyfills': 'polyfills.9a22720c747de39b8217.sv.bundle.js', 'styles': 'styles.09e4280dcb798be8dd72.sv.bundle.css', 'vendor': 'vendor.a7f1323b47e27c923dda.sv.bundle.js' }, 'zh': { 'inline': 'inline.103ff40236c29bbaacbc.zh.bundle.js', 'main': 'main.30e9faef0a0f3e5afee6.zh.bundle.js', 'polyfills': 'polyfills.9a22720c747de39b8217.zh.bundle.js', 'styles': 'styles.09e4280dcb798be8dd72.zh.bundle.css', 'vendor': 'vendor.c6ffff1853a32f777868.zh.bundle.js' } };
function languageSelector() {
    var selectedLanguage = '';
    var fallbackLanguage = '';
    var urlLanguageMatch = locationSearchRegex.exec(location.search) || locationSearchRegex.exec(location.hash);
    if (urlLanguageMatch && urlLanguageMatch[1]) {
        selectedLanguage = urlLanguageMatch[1].toLowerCase().replace('-', '_');
        fallbackLanguage = selectedLanguage.length > 2 ? selectedLanguage.substr(0, 2) : selectedLanguage;
    }
    var chosenLanguage = 'en';
    if (availableLanguages.indexOf(selectedLanguage) > -1) {
        chosenLanguage = selectedLanguage;
    }
    else if (availableLanguages.indexOf(fallbackLanguage) > -1) {
        chosenLanguage = fallbackLanguage;
    }
    console.log('Language selected: ' + chosenLanguage);
    var body$ = $('body');
    // styles and polyfills are independent of the UI language, so always using
    // the base files and not deploying duplicate files
    body$.append('<link href="' + languageConfiguration['en'].styles + '" rel="stylesheet"/>');
    var scripts$ = $('<div/>');
    scripts$.append('<script type="text/javascript" src="' + languageConfiguration[chosenLanguage].inline + '"></script>');
    scripts$.append('<script type="text/javascript" src="' + languageConfiguration['en'].polyfills + '"></script>');
    scripts$.append('<script type="text/javascript" src="' + languageConfiguration[chosenLanguage].vendor + '"></script>');
    scripts$.append('<script type="text/javascript" src="' + languageConfiguration[chosenLanguage].main + '"></script>');
    body$.append(scripts$.children());
}
languageSelector();
