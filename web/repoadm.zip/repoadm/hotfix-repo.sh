#!/bin/sh

#set -x	# Debug

True=0;
False=1;

usage()
{
	echo "[$script]: Usage: start $script <arguments>";
}

###
# Main

script=`basename $0`;
location=`dirname $0`;

if [ -z "$STRS_LOCATION" ]; then
	STRS_LOCATION=`cd $location/.. && pwd`;
fi

cd $STRS_LOCATION || exit 1;

if [ -z "$STRS_JAVA_HOME" ]; then
	. $STRS_LOCATION/.setup_environment
fi

type $STRS_JAVA_HOME/bin/java >/dev/null 2>&1 || {
	echo "[$script]: java is not installed or not in the path";
	exit 1;
}

classPath="lib/repoadm/repoadm.jar:/usr/sap/hdbclient/ngdbc.jar"

arguments=;
keyalias=;
keypass=;
logpath=;
jvm_args=;
arg=;
while true
do
	if [ $# = 0 ]; then
		break;
	fi
	if [ $1 = "-Dstrs.keystore.url" ]; then
		cp="keyalias"
		shift; keyalias="$1";
	elif [ "$1" = "-Dstrs.keystore.password" ]; then
		shift; keypass="$1";
	elif [ "$1" = "-Dlog.path" ]; then
		shift; logpath="$1";
	else
		if [ -z "$arguments" ]; then
			arguments="$1";
		else
			arguments="$arguments $1";
		fi
		if [ "$1" = "-v" ]; then
			shift;
			if [ "$1" = "5.6.1" ]; then
				arguments="$arguments 5.61.0";
         elif [ "$1" = "5.6.2" ]; then
				arguments="$arguments 5.62.0";   
			else
				arguments="$arguments $1";
			fi
		else
			shift;
			arguments="$arguments $1";
		fi
	fi
	shift
done

keyalias=`echo $keyalias | sed 's|file://|file:/|g'`;

if [ -n "$logpath" ]; then
    jvm_args="-Dlog.path=$logpath";
else
		if [ -n "$DBATLOGPATH" ]; then
		    jvm_args="-Dlog.path=$DBATLOGPATH";
		else
		    if [ -n "$STRS_MANAGEMENTGATEWAY_ROOT" ]; then
		        jvm_args="-Dlog.path=$STRS_MANAGEMENTGATEWAY_ROOT/etc";
		        if [ ! -d $STRS_MANAGEMENTGATEWAY_ROOT/etc ]; then
		            jvm_args="-Dlog.path=$HOME";
		        fi
		    fi
		fi
fi

if [ -n "$keyalias" ]; then
	if [ -n $keypass ]; then
		jvm_args="$jvm_args -Dstrs.keystore.url=$keyalias -Dstrs.keystore.password=$keypass";
	else
		jvm_args="$jvm_args -Dstrs.keystore.url=$keyalias";
	fi
fi

exec $STRS_JAVA_HOME/bin/java $jvm_args -cp $classPath com.streamserve.dbadmintools.repocmdl.UpgradeRepository $arguments
