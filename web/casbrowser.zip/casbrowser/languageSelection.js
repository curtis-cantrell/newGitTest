var availableLanguages = ['de', 'es', 'fi', 'fr', 'ja', 'nl', 'pt', 'ru', 'sv', 'zh'];
var locationSearchRegex = /[\?&](?:language|langCode)=([a-z]{2}(?:[-_][a-z]{2,3})?)?/i;
var languageConfiguration = { 'en': { 'inline': 'inline.231d32d43e28e97f9b74.bundle.js', 'polyfills': 'polyfills.7ef7a9c5443f8aacb690.bundle.js', 'main': 'main.7c64bb44ee613a500275.bundle.js', 'styles': 'styles.55a044cc5b0a6bcd8f2a.bundle.css', 'vendor': 'vendor.1d00ce49f3adbfe4847c.bundle.js' }, 'de': { 'inline': 'inline.13cfec854249ac6a42a8.de.bundle.js', 'main': 'main.510ce57488647634f713.de.bundle.js', 'polyfills': 'polyfills.7ef7a9c5443f8aacb690.de.bundle.js', 'styles': 'styles.55a044cc5b0a6bcd8f2a.de.bundle.css', 'vendor': 'vendor.39fd3dac8cc22b5449f3.de.bundle.js' }, 'es': { 'inline': 'inline.3f928457a1a24006bcd4.es.bundle.js', 'main': 'main.0606290af2b00879c9f7.es.bundle.js', 'polyfills': 'polyfills.7ef7a9c5443f8aacb690.es.bundle.js', 'styles': 'styles.55a044cc5b0a6bcd8f2a.es.bundle.css', 'vendor': 'vendor.23d0f9bc339a54e7f205.es.bundle.js' }, 'fi': { 'inline': 'inline.c33f203aed69512c2df5.fi.bundle.js', 'main': 'main.8d48fc6ce31b2d194ac7.fi.bundle.js', 'polyfills': 'polyfills.7ef7a9c5443f8aacb690.fi.bundle.js', 'styles': 'styles.55a044cc5b0a6bcd8f2a.fi.bundle.css', 'vendor': 'vendor.fc5502597cf32708ff69.fi.bundle.js' }, 'fr': { 'inline': 'inline.2103fec9a1e0b60fbddf.fr.bundle.js', 'main': 'main.43b450b1badd770db04a.fr.bundle.js', 'polyfills': 'polyfills.7ef7a9c5443f8aacb690.fr.bundle.js', 'styles': 'styles.55a044cc5b0a6bcd8f2a.fr.bundle.css', 'vendor': 'vendor.11fd1c31f63e39478c07.fr.bundle.js' }, 'ja': { 'inline': 'inline.230995f25f267d76a3cd.ja.bundle.js', 'main': 'main.06beba119e42c9f33e6b.ja.bundle.js', 'polyfills': 'polyfills.7ef7a9c5443f8aacb690.ja.bundle.js', 'styles': 'styles.55a044cc5b0a6bcd8f2a.ja.bundle.css', 'vendor': 'vendor.5bbe1e88dd6d01e6e904.ja.bundle.js' }, 'nl': { 'inline': 'inline.b3483c525ac816c49aa7.nl.bundle.js', 'main': 'main.52d8e629b4dec2e094b3.nl.bundle.js', 'polyfills': 'polyfills.7ef7a9c5443f8aacb690.nl.bundle.js', 'styles': 'styles.55a044cc5b0a6bcd8f2a.nl.bundle.css', 'vendor': 'vendor.2d2d8426bde7c7affd5d.nl.bundle.js' }, 'pt': { 'inline': 'inline.e8b696f82f5ec195f303.pt.bundle.js', 'main': 'main.e29e96f45885cf418997.pt.bundle.js', 'polyfills': 'polyfills.7ef7a9c5443f8aacb690.pt.bundle.js', 'styles': 'styles.55a044cc5b0a6bcd8f2a.pt.bundle.css', 'vendor': 'vendor.d8612a9ac5ecf223d5c1.pt.bundle.js' }, 'ru': { 'inline': 'inline.16ce8d7185aaeb2fb02c.ru.bundle.js', 'main': 'main.30002844fe30340666a4.ru.bundle.js', 'polyfills': 'polyfills.7ef7a9c5443f8aacb690.ru.bundle.js', 'styles': 'styles.55a044cc5b0a6bcd8f2a.ru.bundle.css', 'vendor': 'vendor.8356864afe6fd9b504fd.ru.bundle.js' }, 'sv': { 'inline': 'inline.f713b449617fe85f2375.sv.bundle.js', 'main': 'main.1d3006ec73e3aadd7954.sv.bundle.js', 'polyfills': 'polyfills.7ef7a9c5443f8aacb690.sv.bundle.js', 'styles': 'styles.55a044cc5b0a6bcd8f2a.sv.bundle.css', 'vendor': 'vendor.b562cae4e2071a2b00e5.sv.bundle.js' }, 'zh': { 'inline': 'inline.e474a25aa39490aeac03.zh.bundle.js', 'main': 'main.35da5d99772cdb1e1ce7.zh.bundle.js', 'polyfills': 'polyfills.7ef7a9c5443f8aacb690.zh.bundle.js', 'styles': 'styles.55a044cc5b0a6bcd8f2a.zh.bundle.css', 'vendor': 'vendor.94971ae9bde46b867f27.zh.bundle.js' } };
function languageSelector() {
    var selectedLanguage = '';
    var fallbackLanguage = '';
    var urlLanguageMatch = locationSearchRegex.exec(location.search) || locationSearchRegex.exec(location.hash);
    if (urlLanguageMatch && urlLanguageMatch[1]) {
        selectedLanguage = urlLanguageMatch[1].toLowerCase().replace('-', '_');
        fallbackLanguage = selectedLanguage.length > 2 ? selectedLanguage.substr(0, 2) : selectedLanguage;
    }
    var chosenLanguage = 'en';
    if (availableLanguages.indexOf(selectedLanguage) > -1) {
        chosenLanguage = selectedLanguage;
    }
    else if (availableLanguages.indexOf(fallbackLanguage) > -1) {
        chosenLanguage = fallbackLanguage;
    }
    console.log('Language selected: ' + chosenLanguage);
    $('html').attr('lang', chosenLanguage);
    var body$ = $('body');
    // styles and polyfills are independent of the UI language, so always using
    // the base files and not deploying duplicate files
    body$.append('<link href="' + languageConfiguration['en'].styles + '" rel="stylesheet"/>');
    var scripts$ = $('<div/>');
    scripts$.append('<script type="text/javascript" src="' + languageConfiguration[chosenLanguage].inline + '"></script>');
    scripts$.append('<script type="text/javascript" src="' + languageConfiguration['en'].polyfills + '"></script>');
    scripts$.append('<script type="text/javascript" src="' + languageConfiguration[chosenLanguage].vendor + '"></script>');
    scripts$.append('<script type="text/javascript" src="' + languageConfiguration[chosenLanguage].main + '"></script>');
    body$.append(scripts$.children());
}
languageSelector();
